package com.zaroumia.batch.dao;

public interface FormationDao {

	int count();

}
