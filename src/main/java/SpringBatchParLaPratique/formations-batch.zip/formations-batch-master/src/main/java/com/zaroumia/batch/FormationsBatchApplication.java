package com.zaroumia.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormationsBatchApplication {

	public static void main(final String[] args) {
		SpringApplication.run(FormationsBatchApplication.class, args);
	}

}
