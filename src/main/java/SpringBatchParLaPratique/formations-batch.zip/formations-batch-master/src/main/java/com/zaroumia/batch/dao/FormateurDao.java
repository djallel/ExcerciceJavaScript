package com.zaroumia.batch.dao;

public interface FormateurDao {

	int count();
}
