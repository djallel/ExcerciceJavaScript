package fr.zaroumia.formation.spring;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(final String[] args) {

		// TODO Cr�er un formateur

		// TODO Modifier un formateur

		// TODO R�cup�rer le formateur par son ID

		// TODO Supprimer le formateur

		// TODO R�cup�rer tous les formateurs

	}
}
