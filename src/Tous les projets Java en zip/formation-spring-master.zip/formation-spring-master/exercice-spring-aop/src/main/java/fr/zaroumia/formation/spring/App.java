package fr.zaroumia.formation.spring;

import fr.zaroumia.formation.spring._033.Main033;
import fr.zaroumia.formation.spring._034.Main034;
import fr.zaroumia.formation.spring._035.Main035;

public class App {
	public static void main(final String[] args) {
		Main033.main(null);
		Main034.main(null);
		Main035.main(null);

	}
}
