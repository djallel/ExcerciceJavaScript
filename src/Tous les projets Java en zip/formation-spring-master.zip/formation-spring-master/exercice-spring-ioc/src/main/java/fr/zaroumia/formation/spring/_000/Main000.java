package fr.zaroumia.formation.spring._000;

import fr.zaroumia.formation.spring._001.Main001;
import fr.zaroumia.formation.spring._002.Main002;
import fr.zaroumia.formation.spring._003.Main003;
import fr.zaroumia.formation.spring._004.Main004;
import fr.zaroumia.formation.spring._005.Main005;
import fr.zaroumia.formation.spring._006.Main006;
import fr.zaroumia.formation.spring._007.Main007;
import fr.zaroumia.formation.spring._008.Main008;
import fr.zaroumia.formation.spring._009.Main009;
import fr.zaroumia.formation.spring._010.Main010;
import fr.zaroumia.formation.spring._011.Main011;
import fr.zaroumia.formation.spring._012.Main012;
import fr.zaroumia.formation.spring._013.Main013;
import fr.zaroumia.formation.spring._014.Main014;
import fr.zaroumia.formation.spring._015.Main015;
import fr.zaroumia.formation.spring._016.Main016;
import fr.zaroumia.formation.spring._017.Main017;
import fr.zaroumia.formation.spring._018.Main018;
import fr.zaroumia.formation.spring._019.Main019;
import fr.zaroumia.formation.spring._020.Main020;
import fr.zaroumia.formation.spring._021.Main021;
import fr.zaroumia.formation.spring._022.Main022;
import fr.zaroumia.formation.spring._023.Main023;
import fr.zaroumia.formation.spring._024.Main024;

public class Main000 {
	public static void main(final String[] args) {
		Main001.main(null);
		Main002.main(null);
		Main003.main(null);
		Main004.main(null);
		Main005.main(null);
		Main006.main(null);
		Main007.main(null);
		Main008.main(null);
		Main009.main(null);
		Main010.main(null);
		Main011.main(null);
		Main012.main(null);
		Main013.main(null);
		Main014.main(null);
		Main015.main(null);
		Main016.main(null);
		Main017.main(null);
		Main018.main(null);
		Main019.main(null);
		Main020.main(null);
		Main021.main(null);
		Main022.main(null);
		Main023.main(null);
		Main024.main(null);
	}
}
