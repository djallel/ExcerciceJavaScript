package fr.zaroumia.formation.spring._016;

import org.springframework.stereotype.Component;

@Component
public class MonService {

	MonService() {
		System.out.println("je suis le constructeur de MonService");
	}
}
