package fr.zaroumia.formation.spring._016;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("fr.zaroumia.formation.spring._016")
public class Configuration016 {

	// @Bean
	// public FormationDao formationDao() {
	// return new FormationDaoImpl();
	// }
}
