package fr.zaroumia.formation.spring._008;

public class BeanACreer {

	public void quiSuisJe() {
		System.out.println("je suis un bean cr�e par une factory");
	}
}
