package fr.zaroumia.formation.spring.service;

public interface FormateurService {

}
