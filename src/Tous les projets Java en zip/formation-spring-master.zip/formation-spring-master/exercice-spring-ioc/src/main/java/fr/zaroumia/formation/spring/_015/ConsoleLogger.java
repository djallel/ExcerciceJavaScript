package fr.zaroumia.formation.spring._015;

public class ConsoleLogger implements Logger {

	public ConsoleLogger() {
		System.out.println("je suis une impl�mentation ConsoleLogger");
	}
}