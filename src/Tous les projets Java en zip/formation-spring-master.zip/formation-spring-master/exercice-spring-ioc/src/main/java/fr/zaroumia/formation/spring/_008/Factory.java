package fr.zaroumia.formation.spring._008;

public class Factory {

	public BeanACreer create() {
		return new BeanACreer();
	}
}
