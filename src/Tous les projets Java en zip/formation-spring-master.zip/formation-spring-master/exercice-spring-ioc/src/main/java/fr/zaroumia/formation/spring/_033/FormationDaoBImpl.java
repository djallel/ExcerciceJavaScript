package fr.zaroumia.formation.spring._033;

import java.util.List;

import org.springframework.stereotype.Repository;

import fr.zaroumia.formation.spring.dao.FormationDao;
import fr.zaroumia.formation.spring.modele.Formation;

@Repository
public class FormationDaoBImpl implements FormationDao {

	@Override
	public String quiSuisJe() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Formation> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
