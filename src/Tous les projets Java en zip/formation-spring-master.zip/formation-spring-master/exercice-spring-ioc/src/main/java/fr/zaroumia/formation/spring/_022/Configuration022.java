package fr.zaroumia.formation.spring._022;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("fr.zaroumia.formation.spring._022")
public class Configuration022 {

	// @Bean(initMethod = "init", destroyMethod = "destroy")
	// public Etudiant etudiant() {
	// return new Etudiant();
	// }

}
