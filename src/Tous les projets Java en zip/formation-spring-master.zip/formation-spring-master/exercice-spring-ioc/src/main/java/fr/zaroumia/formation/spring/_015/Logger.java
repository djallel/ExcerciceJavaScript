package fr.zaroumia.formation.spring._015;

public interface Logger {

}
