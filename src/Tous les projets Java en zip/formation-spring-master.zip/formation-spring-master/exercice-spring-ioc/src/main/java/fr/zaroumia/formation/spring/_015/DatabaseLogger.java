package fr.zaroumia.formation.spring._015;

public class DatabaseLogger implements Logger {

	public DatabaseLogger() {
		System.out.println("je suis une impl�mentation DatabaseLogger");
	}
}
