package fr.zaroumia.formation.spring.service;

public class Calculatrice {

	public int addition(final int a, final int b) {
		return a + b;
	}

	public int division(final int a, final int b) {
		return a / b;
	}
}
