package fr.zaroumia.formation.spring.service;

import fr.zaroumia.formation.spring.modele.Formation;

public interface FormationService {

	void create(Formation formation);
}
