export class AppareilModel {
    //name:string;
    //status:string;
    constructor(public name:string, public status:string) {
        
    }
}