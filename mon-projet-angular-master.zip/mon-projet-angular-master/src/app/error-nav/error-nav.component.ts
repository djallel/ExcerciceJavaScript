import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-nav',
  templateUrl: './error-nav.component.html',
  styleUrls: ['./error-nav.component.scss']
})
export class ErrorNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
